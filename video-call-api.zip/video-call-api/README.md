# Agora-Video-Conferencing
A Video-call app built using AGORA to comunicate anywhere, anytime. 
You can:

-  join/leave a channel
- mute/unmute 
- enable/disable the video
